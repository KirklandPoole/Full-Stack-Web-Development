To run this application

1. Navigate to the vagrant environment

2. run database_setup.py to create the database

3. run lotsofmenus.py to populate the database

4. run application.py and navigate to localhost:5000 in your browser

References:
https://github.com/lobrown/Full-Stack-Foundations/tree/master/Lesson-4